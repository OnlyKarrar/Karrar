var _0xad57=["\x2E\x2E\x2F\x63\x6F\x6E\x66\x69\x67\x2E\x6A\x73","\x64\x69\x73\x63\x6F\x72\x64\x2E\x6A\x73","\x72\x75\x6E","\x65\x78\x70\x6F\x72\x74\x73","\u274C\x20\x5F\x5F\x2A\x2A\x4F\x6E\x6C\x79\x20\x74\x68\x65\x20\x6F\x77\x6E\x65\x72\x20\x63\x61\x6E\x20\x75\x73\x65\x20\x74\x68\x69\x73\x20\x43\x6F\x6D\x6D\x61\x6E\x64\x2A\x2A\x5F\x5F","\x73\x65\x74\x44\x65\x73\x63\x72\x69\x70\x74\x69\x6F\x6E","\x23\x66\x66\x30\x30\x30\x30","\x73\x65\x74\x43\x6F\x6C\x6F\x72","\x62\x6F\x74","\x61\x75\x74\x68\x6F\x72","\x67\x75\x69\x6C\x64","\x46\x4C\x41\x47\x53","\x50\x65\x72\x6D\x69\x73\x73\x69\x6F\x6E\x73","\x68\x61\x73","\x70\x65\x72\x6D\x69\x73\x73\x69\x6F\x6E\x73","\x6D\x65\x6D\x62\x65\x72","\x66\x6F\x72\x45\x61\x63\x68","\x20","\x73\x70\x6C\x69\x74","\x63\x6F\x6E\x74\x65\x6E\x74","\x21","\x5E\x3C\x40\x21\x3F","\x69\x64","\x75\x73\x65\x72","\x63\x6C\x69\x65\x6E\x74","\x3E","\x6D\x61\x74\x63\x68","\x57\x65\x6C\x63\x6F\x6D\x65\x20\x69\x6D\x20","\x74\x61\x67","\x20\x4D\x79\x20\x50\x72\x65\x66\x69\x78\x20\x69\x73\x5C\x60","\x5C\x60","\x72\x65\x70\x6C\x79","\x73\x74\x61\x72\x74\x73\x57\x69\x74\x68","\x66\x65\x74\x63\x68\x4D\x65\x6D\x62\x65\x72","\x74\x72\x69\x6D","\x6C\x65\x6E\x67\x74\x68","\x73\x6C\x69\x63\x65","\x74\x6F\x4C\x6F\x77\x65\x72\x43\x61\x73\x65","\x73\x68\x69\x66\x74","\x67\x65\x74","\x63\x6F\x6D\x6D\x61\x6E\x64\x73","\x61\x6C\x69\x61\x73\x65\x73","\x69\x6E\x63\x6C\x75\x64\x65\x73","\x66\x69\x6E\x64","\x62\x6F\x74\x50\x65\x72\x6D\x69\x73\x73\x69\x6F\x6E","\x6D\x65","","\x70\x75\x73\x68","\u274C\x20\x2A\x2A\x20\x49\x20\x64\x6F\x6E\x27\x74\x20\x68\x61\x76\x65\x20\x50\x72\x65\x6D\x69\x73\x73\x69\x6F\x6E\x20\x2D\x20\x5B","\x5D\x2A\x2A","\x73\x65\x6E\x64","\x63\x68\x61\x6E\x6E\x65\x6C","\x61\x75\x74\x68\x6F\x72\x50\x65\x72\x6D\x69\x73\x73\x69\x6F\x6E","\u274C\x20\x2A\x2A\x20\x59\x6F\x75\x20\x64\x6F\x6E\x27\x74\x20\x68\x61\x76\x65\x20\x50\x72\x65\x6D\x69\x73\x73\x69\x6F\x6E\x20\x2D\x20\x5B","\x6F\x77\x6E\x65\x72\x4F\x6E\x6C\x79","\x6F\x77\x6E\x65\x72\x73","\x64\x6D\x4F\x6E\x6C\x79","\x74\x79\x70\x65","\x64\x6D","\x63\x6F\x6F\x6C\x64\x6F\x77\x6E\x73","\x73\x65\x74","\x6E\x6F\x77","\x61\x76\x61\x74\x61\x72\x55\x52\x4C","\x73\x65\x74\x41\x75\x74\x68\x6F\x72","\x2A\x2A\x50\x6C\x65\x61\x73\x65\x20\x57\x69\x74\x65\x20\x43\x6F\x6F\x6C\x44\x6F\x77\x6E\x20","\x74\x6F\x46\x69\x78\x65\x64","\x20\x53\x65\x63\x6F\x6E\x64\x73\x2A\x2A\x21","\x73\x65\x74\x46\x6F\x6F\x74\x65\x72","\x47\x4F\x4C\x44","\x5F\x5F\x2A\x2A\x43\x6F\x6F\x6C\x44\x6F\x77\x6E\x2A\x2A\x5F\x5F","\x73\x65\x74\x54\x69\x74\x6C\x65","\x6D\x65\x73\x73\x61\x67\x65","\x6C\x6F\x67","\x63\x61\x74\x63\x68","\x64\x65\x6C\x65\x74\x65","\x74\x68\x65\x6E"];
const config=require(_0xad57[0]);
const Discord=require(_0xad57[1]);
const {MessageEmbed}=require(_0xad57[1]);
const djs=require(_0xad57[1]),cooldowns= new djs.Collection();
module[_0xad57[3]][_0xad57[2]]= async (_0x1bb5x5,_0x1bb5x6)=>
{
	const _0x1bb5x7= new Discord.MessageEmbed()[_0xad57[7]](`${_0xad57[6]}`)[_0xad57[5]](`${_0xad57[4]}`);
	if(_0x1bb5x6[_0xad57[9]][_0xad57[8]])
	{
		return
	}
	if(!_0x1bb5x6[_0xad57[10]])
	{
		return
	}
	if(!_0x1bb5x6[_0xad57[15]][_0xad57[14]][_0xad57[13]](djs[_0xad57[12]][_0xad57[11]].ADMINISTRATOR))
	{
		_0x1bb5x6[_0xad57[19]][_0xad57[18]](_0xad57[17])[_0xad57[16]]((_0x1bb5x8)=>
		{
		}
		)
	}
	const _0x1bb5x9=_0xad57[20];
	const _0x1bb5xa= new RegExp(`${_0xad57[21]}${_0x1bb5x6[_0xad57[24]][_0xad57[23]][_0xad57[22]]}${_0xad57[25]}`);
	if(_0x1bb5x6[_0xad57[19]][_0xad57[26]](_0x1bb5xa))
	{
		return _0x1bb5x6[_0xad57[31]](`${_0xad57[27]}${_0x1bb5x5[_0xad57[23]][_0xad57[28]]}${_0xad57[29]}${_0x1bb5x9}${_0xad57[30]}`)
	}
	if(!_0x1bb5x6[_0xad57[19]][_0xad57[32]](_0x1bb5x9))
	{
		return
	}
	if(!_0x1bb5x6[_0xad57[15]])
	{
		_0x1bb5x6[_0xad57[15]]=  await _0x1bb5x6[_0xad57[10]][_0xad57[33]](_0x1bb5x6)
	}
	const _0x1bb5xb=_0x1bb5x6[_0xad57[19]][_0xad57[36]](_0x1bb5x9[_0xad57[35]])[_0xad57[34]]()[_0xad57[18]](/ +/g);
	const _0x1bb5xc=_0x1bb5xb[_0xad57[38]]()[_0xad57[37]]();
	if(_0x1bb5xc[_0xad57[35]]=== 0)
	{
		return
	}
	let _0x1bb5xd=_0x1bb5x5[_0xad57[40]][_0xad57[39]](_0x1bb5xc)|| _0x1bb5x5[_0xad57[40]][_0xad57[43]]((_0x1bb5xd)=>
	{
		return _0x1bb5xd[_0xad57[41]]&& _0x1bb5xd[_0xad57[41]][_0xad57[42]](_0x1bb5xc)
	}
	);
	if(!_0x1bb5xd)
	{
		return
	}
	if(!_0x1bb5xd)
	{
		_0x1bb5xd= _0x1bb5x5[_0xad57[40]][_0xad57[39]](_0x1bb5x5[_0xad57[41]][_0xad57[39]](_0x1bb5xc))
	}
	if(!_0x1bb5xd)
	{
		return
	}
	if(_0x1bb5xd[_0xad57[44]])
	{
		let _0x1bb5xe=[];
		_0x1bb5xd[_0xad57[44]][_0xad57[16]]((_0x1bb5xf)=>
		{
			if(!_0x1bb5x6[_0xad57[10]][_0xad57[45]][_0xad57[14]][_0xad57[13]](_0x1bb5xf))
			{
				_0x1bb5xe[_0xad57[47]](_0xad57[46]+ _0x1bb5xf+ _0xad57[46])
			}
		}
		);if(_0x1bb5xe[_0xad57[35]])
		{
			const _0x1bb5x10= new Discord.MessageEmbed()[_0xad57[7]](_0xad57[6])[_0xad57[5]](`${_0xad57[48]}${_0x1bb5xe}${_0xad57[49]}`);
			return _0x1bb5x6[_0xad57[51]][_0xad57[50]]({embeds:[_0x1bb5x10]})
		}
	}
	if(_0x1bb5xd[_0xad57[52]])
	{
		let _0x1bb5xe=[];
		_0x1bb5xd[_0xad57[52]][_0xad57[16]]((_0x1bb5xf)=>
		{
			if(!_0x1bb5x6[_0xad57[15]][_0xad57[14]][_0xad57[13]](_0x1bb5xf))
			{
				_0x1bb5xe[_0xad57[47]](`${_0xad57[46]}${_0x1bb5xf}${_0xad57[46]}`)
			}
		}
		);if(_0x1bb5xe[_0xad57[35]])
		{
			const _0x1bb5x11= new Discord.MessageEmbed()[_0xad57[7]](_0xad57[6])[_0xad57[5]](`${_0xad57[53]}${_0x1bb5xe}${_0xad57[49]}`);
			return _0x1bb5x6[_0xad57[51]][_0xad57[50]]({embeds:[_0x1bb5x11]})
		}
	}
	if(_0x1bb5xd[_0xad57[54]])
	{
		if(!config[_0xad57[55]][_0xad57[42]](_0x1bb5x6[_0xad57[9]][_0xad57[22]]))
		{
			return _0x1bb5x6[_0xad57[51]][_0xad57[50]]({embeds:[_0x1bb5x7]})
		}
	}
	if(_0x1bb5xd[_0xad57[56]])
	{
		if(!_0x1bb5x6[_0xad57[51]][_0xad57[57]]=== _0xad57[58])
		{
			return
		}
	}
	if(!cooldowns[_0xad57[13]](_0x1bb5xd[_0xad57[59]]))
	{
		cooldowns[_0xad57[60]](_0x1bb5xd[_0xad57[59]], new djs.Collection())
	}
	const _0x1bb5x12=_0x1bb5x6[_0xad57[15]],_0x1bb5x13=Date[_0xad57[61]](),_0x1bb5x14=cooldowns[_0xad57[39]](_0x1bb5xd[_0xad57[59]]),_0x1bb5x15=(_0x1bb5xd[_0xad57[59]]|| 3)* 1000;
	if(!_0x1bb5x14[_0xad57[13]](_0x1bb5x12[_0xad57[22]]))
	{
		if(!config[_0xad57[55]][_0xad57[42]](_0x1bb5x6[_0xad57[9]][_0xad57[22]]))
		{
			_0x1bb5x14[_0xad57[60]](_0x1bb5x12[_0xad57[22]],_0x1bb5x13)
		}
	}
	else 
	{
		const _0x1bb5x16=_0x1bb5x14[_0xad57[39]](_0x1bb5x12[_0xad57[22]])+ _0x1bb5x15;
		if(_0x1bb5x13< _0x1bb5x16)
		{
			const _0x1bb5x17=(_0x1bb5x16- _0x1bb5x13)/ 1000;
			const _0x1bb5x18= new Discord.MessageEmbed()[_0xad57[70]](`${_0xad57[69]}`)[_0xad57[7]](`${_0xad57[68]}`)[_0xad57[67]]({text:`${_0xad57[46]}${_0x1bb5x5[_0xad57[23]][_0xad57[28]]}${_0xad57[46]}`,iconURL:`${_0xad57[46]}${_0x1bb5x5[_0xad57[23]][_0xad57[62]]()}${_0xad57[46]}`})[_0xad57[5]](`${_0xad57[64]}${_0x1bb5x17[_0xad57[65]](0)}${_0xad57[66]}`)[_0xad57[63]]({name:_0x1bb5x6[_0xad57[9]][_0xad57[28]],iconURL:_0x1bb5x6[_0xad57[9]][_0xad57[62]]({dynamic:true})});
			return _0x1bb5x6[_0xad57[51]][_0xad57[50]]({embeds:[_0x1bb5x18]})[_0xad57[75]]((_0x1bb5x18)=>
			{
				setTimeout(()=>
				{
					return _0x1bb5x18[_0xad57[74]]()
				}
				,3000)&& _0x1bb5x6[_0xad57[74]]()
			}
			)[_0xad57[73]](async (_0x1bb5x19)=>
			{
				return console[_0xad57[72]](_0x1bb5x19[_0xad57[71]])
			}
			)
		}
		_0x1bb5x14[_0xad57[60]](_0x1bb5x12[_0xad57[22]],_0x1bb5x13);setTimeout(()=>
		{
			return _0x1bb5x14[_0xad57[74]](_0x1bb5x12[_0xad57[22]])
		}
		,_0x1bb5x15)
	}
	if(_0x1bb5xd)
	{
		_0x1bb5xd[_0xad57[2]](_0x1bb5x5,_0x1bb5x6,_0x1bb5xb,config)
	}
}  